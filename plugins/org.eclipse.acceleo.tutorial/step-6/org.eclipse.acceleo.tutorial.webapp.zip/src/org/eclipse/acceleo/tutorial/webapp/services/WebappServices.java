package org.eclipse.acceleo.tutorial.webapp.services;

public class WebappServices {
	public String removeSpaces(String str) {
		return str.replace(" ", "-");
	}
}
