/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.acceleo.tutorial.webapp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Text Area</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.acceleo.tutorial.webapp.WebappPackage#getTextArea()
 * @model
 * @generated
 */
public interface TextArea extends FormWidget {
} // TextArea
