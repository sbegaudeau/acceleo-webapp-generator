/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.acceleo.tutorial.webapp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Static View</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.acceleo.tutorial.webapp.WebappPackage#getStaticView()
 * @model
 * @generated
 */
public interface StaticView extends AbstractView {
} // StaticView
